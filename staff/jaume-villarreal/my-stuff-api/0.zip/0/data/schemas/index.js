module.exports = {
    user : require('./user.js'),
    property : require('./property'),
    vehicle : require('./vehicle'),
    card : require('./card')
}
