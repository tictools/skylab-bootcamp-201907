// const logic = require('../../logic')

// module.exports = function(req , res){
//     const { body : { address , m2 , year , cadastre }} = req

//     try{
//         logic.property.register(address , m2 , year , cadastre)
//     } catch({ message }){
//         res.status(400).json(error : message)
//     }
// }