module.exports = {
    registerProperty : require('./register')
}